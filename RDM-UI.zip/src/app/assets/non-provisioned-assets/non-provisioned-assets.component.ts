import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-non-provisioned-assets',
  templateUrl: './non-provisioned-assets.component.html',
  styleUrls: ['./non-provisioned-assets.component.css']
})
export class NonProvisionedAssetsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
