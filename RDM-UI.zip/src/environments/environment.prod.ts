export const environment = {
  production: true,
  appServerURL: 'https://devkemsysrdmfuntionapp.azurewebsites.net/api/',
  blobAccountName: 'storageaccountkemsy96a3',
  blobContainerName: 'rdm-images',
  blobKey: '?sv=2019-12-12&ss=bfqt&srt=co&sp=rwdlacupx&se=2050-08-24T01:36:54Z&st=2020-08-23T17:36:54Z&spr=https,http&sig=RQIjWkLDMqo6bxn5QtZrBLBQ7qYDn2q2dPZyckV%2FGJc%3D',
  blobURL: 'https://storageaccountkemsy96a3.blob.core.windows.net/',
  cachedTelemetryContainer: 'telemetry',
  app: undefined,
  environment: 'DEV',
  version: '9.0',
  storgageSecretKey: 'kEm$Y$*RdM',
  packageManagementContainer: 'packages'
};
