import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-asset-model-stream-processing',
  templateUrl: './asset-model-stream-processing.component.html',
  styleUrls: ['./asset-model-stream-processing.component.css']
})
export class AssetModelStreamProcessingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
