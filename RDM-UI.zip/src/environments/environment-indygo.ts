export const environment = {
  production: true,
  appServerURL: 'https://indygo-rdm.azurewebsites.net/api/',
  blobAccountName: 'indygo',
  blobContainerName: 'rdm-images',
  blobKey: '?sv=2020-02-10&ss=bf&srt=sco&sp=rwacx&se=2050-06-30T17:10:17Z&st=2021-06-30T09:10:17Z&spr=https,http&sig=WSFpbc01fVyAoys6UdFCH2DCC6B7Nt4BeZ2AIBJ79Do%3D',
  blobURL: 'https://indygo.blob.core.windows.net/',
  cachedTelemetryContainer: 'telemetry',
  app: undefined,
  environment: 'TEST',
  version: '8.0',
  storgageSecretKey: 'kEm$Y$*RdM',
  packageManagementContainer: 'packages'
};
