import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rule-engine',
  templateUrl: './rule-engine.component.html',
  styleUrls: ['./rule-engine.component.css']
})
export class RuleEngineComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
