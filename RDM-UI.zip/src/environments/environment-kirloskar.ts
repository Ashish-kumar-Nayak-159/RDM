export const environment = {
  production: true,
  appServerURL: 'https://kirloskarfunctionapp.azurewebsites.net/api/',
  blobAccountName: 'cmsblobstorageaccount',
  blobContainerName: 'ui-media',
  blobKey: '?sv=2019-12-12&ss=bf&srt=co&sp=rwlac&se=2049-12-31T18:30:00Z&st=2020-12-31T18:30:00Z&spr=https,http&sig=oddGuC1HeJ4b%2F3kCF2cBzUuuOWqBjwg1R0RwAshbb1o%3D',
  blobURL: 'https://cmsblobstorageaccount.blob.core.windows.net/',
  cachedTelemetryContainer: 'telemetry',
  app: 'KCMS',
  environment: 'PROD',
  version: '8.0',
  packageManagementContainer: 'packages',
  storgageSecretKey: 'kIrL0$k@Rcm$'
};
